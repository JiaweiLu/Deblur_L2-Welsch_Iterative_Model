%% remark
% This demo using L2-Welsch iterative model to deblur the Levin et al's datasets.
% Levin et al's datasets includs 4 image-GT, 8 kernel-GT, and a total of 32 blurred images. It belongs to a non-uniform datasets.
% This dataset originates from the following paper:
%       A. Levin, Y. Weiss, F. Durand, and W. T. Freeman,
%       Understanding and evaluating blind deconvolution algorithms,
%       IEEE CVPR 2009.
%
% Author: Jiawei Lu @IMU
% Date: 2023-05-12
% Email: 32236108@mail.imu.edu.cn

%%
clear;
close all;
clc;
warning('off');

% input the non-blind methods path
addpath(genpath('cho_code'));
addpath(genpath('whyte_code'));
addpath(genpath('deconv_outliers_code/code'));

% set the kernel szie of each blurred image
kernel_sizes = ...
    [
    19, 17, 15, 27, 13, 21, 23, 23;
    19, 17, 15, 27, 13, 21, 23, 23;
    19, 17, 15, 27, 13, 21, 23, 23;
    19, 17, 15, 27, 13, 23, 23, 23;
    ];

% initialize the struct opts
opts.prescale = 1;
opts.xk_iter = 3; % number of iterations per layer
opts.k_thresh = 20; % normalization threshold for each layer of iterations
opts.isdisplay_est_kernel = 1; % show the deblurring process
opts.c = 0.1; % reweighted coefficient
opts.gamma_correct = 0.6; % gamma correction

% initialize the timer matrix
time1 = zeros(4, 8);
time2 = zeros(4, 8);
deblur_time = zeros(4, 8);

%% main loop
for img = 1 : 4

    for blur = 1 : 8

        % input the blurred images
        blurName = ['Blurry', num2str(img), '_', num2str(blur), '.png'];
        filename_blur = ['../Data_Levin/Blurry/', blurName];
        y = imread(filename_blur);
        yg = im2double(y);

        % input the GT of image
        originalName = ['Original', num2str(img), '_', num2str(blur), '.png'];
        filename_ori = ['../Data_Levin/img_ground/', originalName];
        ori = imread(filename_ori);
        ori = im2double(ori);

        % input the GT of kernel
        kernelName = ['Kernel', num2str(img), '_', num2str(blur), '.png'];
        filename_kernel = ['../Data_Levin/ker_ground/', kernelName];
        kernel_ori = imread(filename_kernel);
        ker_ori = im2double(kernel_ori);

        fprintf(['===================== ', 'Blurred image ', num2str(img), '_', num2str(blur), ' =====================\n']);

        opts.kernel_size = kernel_sizes(img, blur); % match the kernel sizes with images

        % set the prior coefficients
        lambda_grad = 4e-3; lambda_surface = 4e-3;
        opts.gamma = 4e-3; opts.delta = 2e-3;

        % blind deblurring
        tic;
        [kernel, interim_latent] = blind_deconv(yg, lambda_surface, lambda_grad, opts);
        time1(img, blur) = toc;
        fprintf(['(1) The blur kernel estimation takes ', num2str(time1(img, blur)), ' seconds.\n']);

        % non-blind deblurring
        opts.sigma = 5 / 255;
        opts.reg_str = 8e-3;
        tic;
        Latent_cho = deconv_outlier(yg, kernel, opts.sigma, opts.reg_str); % cho's non-blind method
        time2(img, blur) = toc;
        deblur_time(img, blur) = time1(img, blur) + time2(img, blur);
        fprintf(['(2) The non-blind deblurring takes ', num2str(time2(img, blur)), ' seconds.\n']);
        fprintf(['(3) The blind and non-blind debluring takes ', num2str(deblur_time(img, blur)), ' seconds.\n']);

        % normalize the kernel
        k = kernel - min(kernel(:));
        k = k ./ max(k(:));

        % save the results
        saving_path = '../Data_Levin/Deblur_L2-Welsch/';
        imwrite(Latent_cho, [saving_path, 'L2-Welsch_deblur', num2str(img), '_', num2str(blur), '.png']);
        imwrite(interim_latent, [saving_path, 'L2-Welsch_interim', num2str(img), '_', num2str(blur), '.png']);
        imwrite(k, [saving_path, 'L2-Welsch_kernel', num2str(img), '_', num2str(blur), '.png']);

    end

end
