sigma = 1/255;
reg_str = 0.005; % larger reg_str, less ring effect
deblurred = deconv_outlier(y, kernel, sigma, reg_str);

figure
imshow(deblurred);

xx = deblurred;
xx(xx>1) = 1;
xx(xx<0) = 0;